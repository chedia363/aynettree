<?php
/* Smarty version 3.1.33, created on 2019-11-12 15:12:04
  from 'C:\laragon\www\aaynet\content\themes\default\templates\admin.newsletter.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dcacbc43281a4_56165054',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a7f0f444c7f11c5ff1939efbc2457621ecee332b' => 
    array (
      0 => 'C:\\laragon\\www\\aaynet\\content\\themes\\default\\templates\\admin.newsletter.tpl',
      1 => 1573481260,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dcacbc43281a4_56165054 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="card">
    <div class="card-header with-icon">
        <i class="fa fa-paper-plane mr10"></i><?php echo __("Newsletter");?>

    </div>

    <!-- Newsletter -->
    <form class="js_ajax-forms " data-url="admin/newsletter.php">
        <div class="card-body">
            <div class="form-group form-row">
                <label class="col-md-3 form-control-label">
                    <?php echo __("Subject");?>

                </label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" name="subject">
                </div>
            </div>
            
            <div class="form-group form-row">
                <label class="col-md-3 form-control-label">
                    <?php echo __("Message");?>

                </label>
                <div class="col-sm-9">
                    <textarea class="form-control" rows="10" name="message"></textarea>
                </div>
            </div>

            <div class="form-group form-row">
                <label class="col-md-3 form-control-label">
                    <?php echo __("Is HTML");?>

                </label>
                <div class="col-sm-9">
                    <label class="switch" for="is_html">
                        <input type="checkbox" name="is_html" id="is_html">
                        <span class="slider round"></span>
                    </label>
                    <span class="form-text">
                        <?php echo __("The message will be sent as HTML instead of plain text");?>

                    </span>
                </div>
            </div>

            <div class="form-group form-row">
                <label class="col-md-3 form-control-label">
                    <?php echo __("Send to");?>

                </label>
                <div class="col-sm-9">
                    <select class="form-control" name="to">
                        <option value="all"><?php echo __("All Users");?>
</option>
                        <option value="active"><?php echo __("Active Users");?>
</option>
                        <option value="inactive"><?php echo __("Inactive Users");?>
</option>
                    </select>
                </div>
            </div>

            <div class="form-group form-row">
                <label class="col-md-3 form-control-label">
                    <?php echo __("Test Message");?>

                </label>
                <div class="col-sm-9">
                    <label class="switch" for="is_test">
                        <input type="checkbox" name="is_test" id="is_test">
                        <span class="slider round"></span>
                    </label>
                    <span class="form-text">
                        <?php echo __("The message will sent to Website Email only");?>

                    </span>
                </div>
            </div>

            <!-- success -->
            <div class="alert alert-success mb0 x-hidden"></div>
            <!-- success -->

            <!-- error -->
            <div class="alert alert-danger mb0 x-hidden"></div>
            <!-- error -->
        </div>
        <div class="card-footer text-right">
            <button type="submit" class="btn btn-success">
                <i class="fa fa-paper-plane mr10"></i><?php echo __("Send");?>

            </button>
        </div>
    </form>
    <!-- Newsletter -->

</div><?php }
}
