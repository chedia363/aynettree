<?php
/* Smarty version 3.1.33, created on 2019-11-12 12:51:04
  from 'C:\laragon\www\aaynet\content\themes\default\templates\groups.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dcaaab82bb8b4_74038633',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6b9dd18cdfaa337f0148da0bd0af89c7db460edf' => 
    array (
      0 => 'C:\\laragon\\www\\aaynet\\content\\themes\\default\\templates\\groups.tpl',
      1 => 1573558635,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:_head.tpl' => 1,
    'file:_header.tpl' => 1,
    'file:_sidebar.tpl' => 1,
    'file:__feeds_group.tpl' => 1,
    'file:_footer.tpl' => 1,
  ),
),false)) {
function content_5dcaaab82bb8b4_74038633 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:_head.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:_header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<!-- page content -->
<div class="container mt20 offcanvas">
    <div class="row">

        <!-- side panel -->
        <div class="col-md-4 col-lg-3 offcanvas-sidebar js_sticky-sidebar">
            <?php $_smarty_tpl->_subTemplateRender('file:_sidebar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
        </div>
        <!-- side panel -->

        <!-- content panel -->
        <div class="col-md-8 col-lg-9 offcanvas-mainbar">

            <!-- tabs -->
            <div class="content-tabs rounded-sm shadow-sm clearfix">
                <ul>
                    <li <?php if ($_smarty_tpl->tpl_vars['view']->value == '') {?>class="active"<?php }?>>
                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups"><?php echo __("Panels");?>
</a>
                    </li>
                    <?php if ($_smarty_tpl->tpl_vars['user']->value->_data['user_group'] < 3 && $_smarty_tpl->tpl_vars['system']->value['groups_enabled']) {?>
                    <li <?php if ($_smarty_tpl->tpl_vars['view']->value == "manage") {?>class="active"<?php }?>>
                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/manage"><?php echo __("My panels");?>
</a>
                    </li>
                    <?php }?>
                    <li <?php if ($_smarty_tpl->tpl_vars['view']->value == "joined") {?>class="active"<?php }?>>
                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/joined"><?php echo __("Joined Panels");?>
</a>
                    </li>
                    
                </ul>
                <?php if ($_smarty_tpl->tpl_vars['user']->value->_data['user_group'] < 2 && $_smarty_tpl->tpl_vars['system']->value['groups_enabled']) {?>
                    <div class="mt10 float-right">
                        <button class="btn btn-sm btn-success d-none d-lg-block" data-toggle="modal" data-url="#create-group">
                            <i class="fa fa-plus-circle mr5"></i><?php echo __("Create your group");?>

                        </button>
                        <button class="btn btn-sm btn-icon btn-success d-block d-lg-none" data-toggle="modal" data-url="#create-group">
                            <i class="fa fa-plus-circle"></i>
                        </button>
                    </div>
                <?php }?>
            </div>
            <!-- tabs -->
            <?php if ($_smarty_tpl->tpl_vars['view']->value == '') {?>
            <div class="groupsguran">
                <div class="row">
                    <div class="col-md-12 col-lg-6">
                        <div class="ui-box boxgroup">
                            <div class="mt10">
                                <div> <h3 class="titlegroupay"><?php echo __("The Glorious Qur'an");?>
</h3></div>
                                
                                <ul>
                                    <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/gr1"class="groupcolor">
                                            <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Tajwid");?>

                                        </a>
                                    </li>
                                        <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/gr2" class="groupcolor">
                                            <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Qira'at (Modes of Qur’anic Reading)");?>

                                        </a>
                                    </li>
                                        <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/gr3"class="groupcolor">
                                            <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Qur'an Albums");?>

                                        </a>
                                    </li>
                                </ul>
                             </div>
                        </div>
                    </div>
                      <div class="col-md-12 col-lg-6">
                        <div class="ui-box boxgroup">
                            <div class="mt10">
                                <div> <h3 class="titlegroupay"><?php echo __("Tafsir and Qur'anic Sciences");?>
</h3></div>
                                
                                <ul>
                                    <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/gr4" class="groupcolor">
                                            <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Tafsir (Exegesis)");?>

                                        </a>
                                    </li>
                                        <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/gr5" class="groupcolor">
                                            <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Qur'anic Sciences");?>

                                        </a>
                                    </li>
                                 
                                </ul>
                             </div>
                        </div>
                    </div>
                     
                </div>
                <div class="row">
                <div class="col-md-12 col-lg-6">
                        <div class="ui-box boxgroup">
                            <div class="mt10">
                               
                                 <div> <h3 class="titlegroupay"><?php echo __("Different Languages");?>
</h3></div>
                                
                                <ul>
                                    <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/gr6" class="groupcolor">
                                            <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Qur'an Translations");?>

                                        </a>
                                    </li>
                                        <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/gr7" class="groupcolor">
                                            <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Sign Language");?>

                                        </a>
                                    </li>
                                        <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/gr8" class="groupcolor">
                                            <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Braille");?>

                                        </a>
                                    </li>
                                </ul>
                             </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-6">
                        <div class="ui-box boxgroup">
                            <div class="mt10">
                              
                                <div> <h3 class="titlegroupay"><?php echo __("Media");?>
</h3></div>
                                
                                <ul>
                                    <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/gr9" class="groupcolor">
                                            <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Movie Making");?>

                                        </a>
                                    </li>
                                        <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/gr10" class="groupcolor">
                                            <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Competitions");?>

                                        </a>
                                    </li>
                                        <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/gr11" class="groupcolor">
                                            <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Events ");?>

                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/gr12" class="groupcolor">
                                            <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Eminent Persons");?>

                                        </a>
                                    </li>
                                </ul>
                             </div>
                        </div>
                    </div>
                </div>

                 <div class="row">
                   
                      <div class="col-md-12 col-lg-6">
                        <div class="ui-box boxgroup">
                            <div class="mt10">
                             
                                <div> <h3 class="titlegroupay"><?php echo __("Skills");?>
</h3></div>
                                
                                <ul>
                                    <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/gr13" class="groupcolor">
                                            <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Calligraphy");?>

                                        </a>
                                    </li>
                                        <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/gr14" class="groupcolor">
                                            <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Ornamentation");?>

                                        </a>
                                    </li>
                                        <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/gr15" class="groupcolor">
                                            <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Designing");?>

                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/gr16" class="groupcolor">
                                            <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Montage (Film editing)");?>

                                        </a>
                                    </li>
                                </ul>
                             </div>
                        </div>
                    </div>
                      <div class="col-md-12 col-lg-6">
                        <div class="ui-box boxgroup">
                            <div class="mt10">
                                
                                <div> <h3 class="titlegroupay"><?php echo __("Technology");?>
</h3></div>
                                
                                <ul>
                                    <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/gr17" class="groupcolor">
                                            <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Programs, Applications");?>

                                        </a>
                                    </li>
                                        <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/gr18" class="groupcolor">
                                            <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Programming");?>

                                        </a>
                                    </li>
                                        <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups/gr19" class="groupcolor">
                                            <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Technology Products");?>

                                        </a>
                                    </li>
                                </ul>
                             </div>
                        </div>
                    </div>
                </div>
            </div>
            

            <?php } else { ?>
            <!-- content -->
            <div>
                <?php if ($_smarty_tpl->tpl_vars['groups']->value) {?>
                    <ul class="row">
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['groups']->value, '_group');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['_group']->value) {
?>
                            <?php $_smarty_tpl->_subTemplateRender('file:__feeds_group.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('_tpl'=>'box'), 0, true);
?>
                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </ul>

                    <!-- see-more -->
                    <?php if (count($_smarty_tpl->tpl_vars['groups']->value) >= $_smarty_tpl->tpl_vars['system']->value['max_results_even']) {?>
                        <div class="alert alert-post see-more js_see-more" data-get="<?php echo $_smarty_tpl->tpl_vars['get']->value;?>
" data-uid="<?php echo $_smarty_tpl->tpl_vars['user']->value->_data['user_id'];?>
">
                            <span><?php echo __("See More");?>
</span>
                            <div class="loader loader_small x-hidden"></div>
                        </div>
                    <?php }?>
                    <!-- see-more -->
                <?php } else { ?>
                    <p class="text-center text-muted">
                        <?php echo __("No groups to show");?>

                    </p>
                <?php }?>
            </div>
            <?php }?>
            <!-- content -->

        </div>
        <!-- content panel -->
        <!--<?php echo var_dump();?>
-->
                            
    </div>
</div>
<!-- page content -->

<?php $_smarty_tpl->_subTemplateRender('file:_footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
