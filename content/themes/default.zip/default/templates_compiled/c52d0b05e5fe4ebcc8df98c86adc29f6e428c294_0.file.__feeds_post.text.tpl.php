<?php
/* Smarty version 3.1.33, created on 2019-11-12 09:00:16
  from 'C:\laragon\www\aaynet\content\themes\default\templates\__feeds_post.text.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dca74a00e74d2_72808572',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c52d0b05e5fe4ebcc8df98c86adc29f6e428c294' => 
    array (
      0 => 'C:\\laragon\\www\\aaynet\\content\\themes\\default\\templates\\__feeds_post.text.tpl',
      1 => 1573481260,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dca74a00e74d2_72808572 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="post-replace">
    <div class="post-text js_readmore" dir="auto"><?php echo $_smarty_tpl->tpl_vars['post']->value['text'];?>
</div>
    <div class="post-text-translation x-hidden" dir="auto"></div>
    <div class="post-text-plain x-hidden"><?php echo $_smarty_tpl->tpl_vars['post']->value['text_plain'];?>
</div>
</div><?php }
}
