<?php
/* Smarty version 3.1.33, created on 2019-11-12 15:58:12
  from 'C:\laragon\www\aaynet\content\themes\default\templates\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dcad694916b89_65918029',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '788230eb7d3e0fcd2285a4f6123242baa421bef9' => 
    array (
      0 => 'C:\\laragon\\www\\aaynet\\content\\themes\\default\\templates\\index.tpl',
      1 => 1573573671,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:_head.tpl' => 1,
    'file:_header.tpl' => 1,
    'file:_footer.links.tpl' => 1,
    'file:_sidebar.tpl' => 1,
    'file:_announcements.tpl' => 1,
    'file:_boosted_post.tpl' => 1,
    'file:_posts.tpl' => 6,
    'file:__feeds_page.tpl' => 2,
    'file:_ads_campaigns.tpl' => 1,
    'file:_ads.tpl' => 1,
    'file:_widget.tpl' => 1,
    'file:__feeds_user.tpl' => 1,
    'file:__feeds_group.tpl' => 1,
    'file:__feeds_event.tpl' => 1,
    'file:_footer.tpl' => 1,
  ),
),false)) {
function content_5dcad694916b89_65918029 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:_head.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:_header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<!-- page content -->
<?php if (!$_smarty_tpl->tpl_vars['user']->value->_logged_in) {?>
<div class="slider--container">
    <div class="slider-content">
        <div class="container pt10 offcanvas">
       		<div class="slider--heading">
                <h1 class="titleaynat"><?php echo __("Welcome To Aaynet");?>
</h1>
                <p class="titleaynatt"><?php echo __("Learn about the benefits of joining aaynet.");?>
</p>
                <div class="title-icons text-justify">
                    <img class="iconsblanc" src="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/content/themes/<?php echo $_smarty_tpl->tpl_vars['system']->value['theme'];?>
/images/icons/groupsblancc.svg"> <span><?php echo __("Specialit Panels");?>
 </span><br> <br>
                    <img class="iconsblanc" src="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/content/themes/<?php echo $_smarty_tpl->tpl_vars['system']->value['theme'];?>
/images/icons/dailysession.svg"> <span><?php echo __("Daily sessions");?>
 </span><br> <br>
                    <img class="iconsblanc" src="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/content/themes/<?php echo $_smarty_tpl->tpl_vars['system']->value['theme'];?>
/images/icons/membersblanc.svg"> <span><?php echo __("Scholars and Skilled Specialists");?>
 </span>
                </div>
                <div class="visitor-btn">
                    <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/signin" class="btn btn-defaultv">    <img class="iconsblanc" src="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/content/themes/<?php echo $_smarty_tpl->tpl_vars['system']->value['theme'];?>
/images/icons/signin.svg">  <?php echo __("Sign In");?>
</a>
                </div>
                <div class="visitor-btn">
                    <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/signup" class="btn btn-defaultv">  <img class="iconsblanc" src="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/content/themes/<?php echo $_smarty_tpl->tpl_vars['system']->value['theme'];?>
/images/icons/signup.svg">  <?php echo __("Sign Up");?>
</a>
                </div>
                 <div class="visitor-btnn">
                    <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/directory/posts" class="btn btn-defaultvisitor">  <img class="iconsblanc"  src="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/content/themes/<?php echo $_smarty_tpl->tpl_vars['system']->value['theme'];?>
/images/icons/visitor.svg">  <?php echo __("Visitor");?>
</a>
                </div>
		    </div>
        </div>
      
     </div>
    <img class="slider--image" src="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/content/themes/<?php echo $_smarty_tpl->tpl_vars['system']->value['theme'];?>
/images/gaynet.jpg" alt="winter-01" />
    <img class="slider--image" src="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/content/themes/<?php echo $_smarty_tpl->tpl_vars['system']->value['theme'];?>
/images/gaynet1.jpg" alt="winter-02" />
    <img class="slider--image" src="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/content/themes/<?php echo $_smarty_tpl->tpl_vars['system']->value['theme'];?>
/images/gaynet3.jpg" alt="winter-03" />
</div>
 <?php $_smarty_tpl->_subTemplateRender('file:_footer.links.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
} else { ?>
    <div class="container mt20 offcanvas">
        <div class="row">

            <!-- side panel -->
            <div class="col-md-4 col-lg-3 offcanvas-sidebar js_sticky-sidebar">
                <?php $_smarty_tpl->_subTemplateRender('file:_sidebar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
                <!-- addcardsection -->
               <!-- <div class="card">
                    <div class="card-body with-nav">
                        <ul class="side-nav">
                            <li <?php if ($_smarty_tpl->tpl_vars['page']->value == "groups") {?>class="active"<?php }?>>
                                <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
">
                                    <?php echo __("Shortcuts");?>

                                </a>
                                <div>
                                <ul>
                                    <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
">
                                            <?php echo __("Your reply today");?>

                                        </a>
                                    </li>
                                </ul>
                                </div>
                            </li>
                        </ul>
                        <div class="card cardAyQur">
                         <p class="text-justify"><?php echo __("وَتَرَى ٱلشَّمْسَ إِذَا طَلَعَت تَّزَٰوَرُ عَن كَهْفِهِمْ ذَاتَ ٱلْيَمِينِ وَإِذَا غَرَبَت تَّقْرِضُهُمْ ذَاتَ ٱلشِّمَالِ وَهُمْ فِى فَجْوَةٍۢ مِّنْهُ ۚ ذَٰلِكَ مِنْ ءَايَٰتِ ٱللَّهِ ۗ مَن يَهْدِ ٱللَّهُ فَهُوَ ٱلْمُهْتَدِ ۖ وَمَن يُضْلِلْ فَلَن تَجِدَ لَهُۥ وَلِيًّۭا مُّرْشِدًۭا");?>
 </p>
                         
                        </div>
                         <ul class="side-nav">
                            <div>
                                <ul>
                                    <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
">
                                          <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Meanings of words");?>

                                        </a>
                                    </li>
                                     <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
">
                                          <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Causes of descent");?>

                                        </a>
                                    </li>
                                     <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
">
                                          <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Stories of the Holy Quran");?>

                                        </a>
                                    </li>
                                    <li>
                                      
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
">
                                          <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("Latest boards");?>

                                        </a>
                                    </li>
                                     <li>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
">
                                          <i class="fa fa-genderless" aria-hidden="true"></i>
                                            <?php echo __("The most interactive councils");?>


                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </ul>

                    </div>
                <!-- </div> -->
                  <!-- addcardsection -->
            </div>
            <!-- side panel -->

            <!-- content panel -->
            <div class="col-md-8 col-lg-9 offcanvas-mainbar">
                <div class="row">
                    <!-- center panel -->
                    <div class="col-lg-8">

                        <!-- announcments -->
                        <?php $_smarty_tpl->_subTemplateRender('file:_announcements.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
                        <!-- announcments -->

                        <?php if ($_smarty_tpl->tpl_vars['view']->value == '') {?>

                            <!-- stories -->
                            <?php if ($_smarty_tpl->tpl_vars['system']->value['stories_enabled']) {?>
                                <div class="card">
                                    <div class="card-header bg-transparent border-bottom-0">
                                        <strong class="text-muted"><?php echo __("Stories");?>
</strong>
                                        <div class="d-none d-sm-block text-muted pointer float-right">
                                            <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title='<?php echo __("Stories are photos and videos that only last 24 hours");?>
'></i>
                                        </div>
                                    </div>
                                    <div class="card-body pt5 stories-wrapper">
                                        <div id="stories" data-json='<?php echo $_smarty_tpl->tpl_vars['stories']->value["json"];?>
'>
                                            <div class="add-story" data-toggle="modal" data-url="posts/story.php?do=create">
                                                <div class="img" style="background-image:url(<?php echo $_smarty_tpl->tpl_vars['user']->value->_data['user_picture'];?>
);">
                                                </div>
                                                <div class="add">
                                                    <i class="fa fa-plus-circle"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php }?>
                            <!-- stories -->

                            <!-- publisher -->
                          
                            <div class="publisher" style="display: none;"> </div>
                            <!-- publisher -->

                            <!-- boosted post -->
                            <?php if ($_smarty_tpl->tpl_vars['boosted_post']->value) {?>
                                <?php $_smarty_tpl->_subTemplateRender('file:_boosted_post.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('post'=>$_smarty_tpl->tpl_vars['boosted_post']->value), 0, false);
?>
                            <?php }?>
                            <!-- boosted post -->

                            <!-- posts -->
                            <?php $_smarty_tpl->_subTemplateRender('file:_posts.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('_get'=>"newsfeed"), 0, false);
?>
                            <!-- posts -->

                        <?php } elseif ($_smarty_tpl->tpl_vars['view']->value == "popular") {?>
                            <!-- saved posts -->
                            <?php $_smarty_tpl->_subTemplateRender('file:_posts.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('_get'=>"popular",'_title'=>__("Popular Posts")), 0, true);
?>
                            <!-- saved posts -->

                        <?php } elseif ($_smarty_tpl->tpl_vars['view']->value == "saved") {?>
                            <!-- saved posts -->
                            <?php $_smarty_tpl->_subTemplateRender('file:_posts.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('_get'=>"saved",'_title'=>__("Saved Posts")), 0, true);
?>
                            <!-- saved posts -->

                        <?php } elseif ($_smarty_tpl->tpl_vars['view']->value == "articles") {?>
                            <!-- articles posts -->
                            <?php $_smarty_tpl->_subTemplateRender('file:_posts.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('_get'=>"posts_profile",'_id'=>$_smarty_tpl->tpl_vars['user']->value->_data['user_id'],'_filter'=>"article",'_title'=>__("My Articles")), 0, true);
?>
                            <!-- articles posts -->

                        <?php } elseif ($_smarty_tpl->tpl_vars['view']->value == "products") {?>
                            <!-- products posts -->
                            <?php $_smarty_tpl->_subTemplateRender('file:_posts.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('_get'=>"posts_profile",'_id'=>$_smarty_tpl->tpl_vars['user']->value->_data['user_id'],'_filter'=>"product",'_title'=>__("My Products")), 0, true);
?>
                            <!-- products posts -->

                        <?php } elseif ($_smarty_tpl->tpl_vars['view']->value == "boosted_posts") {?>
                            <?php if ($_smarty_tpl->tpl_vars['user']->value->_is_admin || $_smarty_tpl->tpl_vars['user']->value->_data['user_subscribed']) {?>
                                <!-- boosted posts -->
                                <?php $_smarty_tpl->_subTemplateRender('file:_posts.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('_get'=>"boosted",'_title'=>__("My Boosted Posts")), 0, true);
?>
                                <!-- boosted posts -->
                            <?php } else { ?>
                                <!-- upgrade -->
                                <div class="alert alert-warning">
                                    <div class="icon">
                                        <i class="fa fa-id-card fa-2x"></i>
                                    </div>
                                    <div class="text">
                                        <strong><?php echo __("Membership");?>
</strong><br>
                                        <?php echo __("Choose the Plan That's Right for You");?>
, <?php echo __("Check the package from");?>
 <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/packages"><?php echo __("Here");?>
</a>
                                    </div>
                                </div>
                                <div class="text-center">
                                    <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/packages" class="btn btn-primary"><i class="fa fa-rocket mr5"></i><?php echo __("Upgrade to Pro");?>
</a>
                                </div>
                                <!-- upgrade -->
                            <?php }?>

                        <?php } elseif ($_smarty_tpl->tpl_vars['view']->value == "boosted_pages") {?>
                            <?php if ($_smarty_tpl->tpl_vars['user']->value->_is_admin || $_smarty_tpl->tpl_vars['user']->value->_data['user_subscribed']) {?>
                                <div class="card">
                                    <div class="card-header">
                                        <strong><?php echo __("My Boosted Pages");?>
</strong>
                                    </div>
                                    <div class="card-body">
                                        <?php if ($_smarty_tpl->tpl_vars['boosted_pages']->value) {?>
                                            <ul>
                                                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['boosted_pages']->value, '_page');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['_page']->value) {
?>
                                                    <?php $_smarty_tpl->_subTemplateRender('file:__feeds_page.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('_tpl'=>"list"), 0, true);
?>
                                                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                            </ul>

                                            <?php if (count($_smarty_tpl->tpl_vars['boosted_pages']->value) >= $_smarty_tpl->tpl_vars['system']->value['max_results_even']) {?>
                                            <!-- see-more -->
                                            <div class="alert alert-info see-more js_see-more" data-get="boosted_pages">
                                                <span><?php echo __("See More");?>
</span>
                                                <div class="loader loader_small x-hidden"></div>
                                            </div>
                                            <!-- see-more -->
                                            <?php }?>
                                        <?php } else { ?>
                                            <p class="text-center text-muted mt10">
                                                <?php echo __("No pages to show");?>

                                            </p>
                                        <?php }?>
                                    </div>
                                </div>
                            <?php } else { ?>
                                <!-- upgrade -->
                                <div class="alert alert-warning">
                                    <div class="icon">
                                        <i class="fa fa-id-card fa-2x"></i>
                                    </div>
                                    <div class="text">
                                        <strong><?php echo __("Membership");?>
</strong><br>
                                        <?php echo __("Choose the Plan That's Right for You");?>
, <?php echo __("Check the package from");?>
 <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/packages"><?php echo __("Here");?>
</a>
                                    </div>
                                </div>
                                <div class="text-center">
                                    <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/packages" class="btn btn-primary"><i class="fa fa-rocket mr5"></i><?php echo __("Upgrade to Pro");?>
</a>
                                </div>
                                <!-- upgrade -->
                            <?php }?>

                        <?php }?>
                    </div>
                    <!-- center panel -->

                    <!-- right panel -->
                    <div class="col-lg-4 js_sticky-sidebar">
                        
                        <!-- pro users -->
                        <?php if ($_smarty_tpl->tpl_vars['pro_members']->value) {?>
                            <div class="card bg-gradient-indigo border-0">
                                <div class="card-header ptb20 bg-transparent border-bottom-0">
                                    <?php if ($_smarty_tpl->tpl_vars['system']->value['packages_enabled'] && !$_smarty_tpl->tpl_vars['user']->value->_data['user_subscribed']) {?>
                                        <div class="float-right">
                                            <small><a class="text-white text-underline" href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/packages"><?php echo __("Upgrade");?>
</a></small>
                                        </div>
                                    <?php }?>
                                    <h6 class="pb0"><i class="fa fa-user-shield mr5"></i> <?php echo __("Pro Users");?>
</h6>
                                </div>
                                <div class="card-body pt0 plr5">
                                    <div class="pro-box-wrapper <?php if (count($_smarty_tpl->tpl_vars['pro_members']->value) > 3) {?>js_slick<?php } else { ?>full-opacity<?php }?>">
                                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['pro_members']->value, '_member');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['_member']->value) {
?>
                                            <a class="user-box text-white" href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/<?php echo $_smarty_tpl->tpl_vars['_member']->value['user_name'];?>
">
                                                <img alt="<?php echo $_smarty_tpl->tpl_vars['_member']->value['user_firstname'];?>
 <?php echo $_smarty_tpl->tpl_vars['_member']->value['user_lastname'];?>
" src="<?php echo $_smarty_tpl->tpl_vars['_member']->value['user_picture'];?>
" />
                                                <div class="name" title="<?php echo $_smarty_tpl->tpl_vars['_member']->value['user_firstname'];?>
 <?php echo $_smarty_tpl->tpl_vars['_member']->value['user_lastname'];?>
">
                                                    <?php echo $_smarty_tpl->tpl_vars['_member']->value['user_firstname'];?>
 <?php echo $_smarty_tpl->tpl_vars['_member']->value['user_lastname'];?>

                                                </div>
                                            </a>
                                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                    </div>
                                </div>
                            </div>
                        <?php }?>
                        <!-- pro users -->

                        <!-- pro pages -->
                        <?php if ($_smarty_tpl->tpl_vars['promoted_pages']->value) {?>
                            <div class="card bg-gradient-teal border-0">
                                <div class="card-header ptb20 bg-transparent border-bottom-0">
                                    <?php if ($_smarty_tpl->tpl_vars['system']->value['packages_enabled'] && !$_smarty_tpl->tpl_vars['user']->value->_data['user_subscribed']) {?>
                                        <div class="float-right">
                                            <small><a class="text-white text-underline" href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/packages"><?php echo __("Upgrade");?>
</a></small>
                                        </div>
                                    <?php }?>
                                    <h6 class="pb0"><i class="fa fa-flag-checkered mr5"></i> <?php echo __("Pro Pages");?>
</h6>
                                </div>
                                <div class="card-body pt0 plr5">
                                    <div class="pro-box-wrapper <?php if (count($_smarty_tpl->tpl_vars['promoted_pages']->value) > 3) {?>js_slick<?php } else { ?>full-opacity<?php }?>">
                                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['promoted_pages']->value, '_page');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['_page']->value) {
?>
                                            <a class="user-box text-white" href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/pages/<?php echo $_smarty_tpl->tpl_vars['_page']->value['page_name'];?>
">
                                                <img alt="<?php echo $_smarty_tpl->tpl_vars['_page']->value['page_title'];?>
" src="<?php echo $_smarty_tpl->tpl_vars['_page']->value['page_picture'];?>
" />
                                                <div class="name" title="<?php echo $_smarty_tpl->tpl_vars['_page']->value['page_title'];?>
">
                                                    <?php echo $_smarty_tpl->tpl_vars['_page']->value['page_title'];?>

                                                </div>
                                            </a>
                                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                    </div>
                                </div>
                            </div>
                        <?php }?>
                        <!-- pro pages -->

                        <!-- trending -->
                        <?php if ($_smarty_tpl->tpl_vars['trending_hashtags']->value) {?>
                            <div class="card bg-gradient-red border-0">
                                <div class="card-header pt20 pb10 bg-transparent border-bottom-0">
                                    <h6 class="mb0"><i class="fa fa-fire mr5"></i> <?php echo __("Trending");?>
</h6>
                                </div>
                                <div class="card-body pt0">
                                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['trending_hashtags']->value, 'hashtag');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['hashtag']->value) {
?>
                                        <a class="trending-item" href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/search/hashtag/<?php echo $_smarty_tpl->tpl_vars['hashtag']->value['hashtag'];?>
">
                                            <span class="hash">
                                                #<?php echo $_smarty_tpl->tpl_vars['hashtag']->value['hashtag'];?>

                                            </span>
                                            <span class="frequency">
                                                <?php echo $_smarty_tpl->tpl_vars['hashtag']->value['frequency'];?>
 <?php echo __("Posts");?>

                                            </span>
                                        </a>
                                    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                </div>
                            </div>
                        <?php }?>
                        <!-- trending -->

                        <?php $_smarty_tpl->_subTemplateRender('file:_ads_campaigns.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
                        <?php $_smarty_tpl->_subTemplateRender('file:_ads.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
                        <?php $_smarty_tpl->_subTemplateRender('file:_widget.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

                        <!-- friend suggestions -->
                        <?php if (count($_smarty_tpl->tpl_vars['user']->value->_data['new_people']) > 0) {?>
                            <div class="card">
                                <div class="card-header bg-transparent">
                                    <div class="float-right">
                                        <small><a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/people"><?php echo __("See All");?>
</a></small>
                                    </div>
                                    <?php echo __("Friend Suggestions");?>

                                </div>
                                <div class="card-body with-list">
                                    <ul>
                                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['user']->value->_data['new_people'], '_user');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['_user']->value) {
?>
                                        <?php $_smarty_tpl->_subTemplateRender('file:__feeds_user.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('_tpl'=>"list",'_connection'=>"add",'_small'=>true), 0, true);
?>
                                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                    </ul>
                                </div>
                            </div>
                        <?php }?>
                         <!-- friend suggestions -->

                        <!-- suggested pages -->
                        <?php if (count($_smarty_tpl->tpl_vars['new_pages']->value) > 0) {?>
                            <div class="card">
                                <div class="card-header bg-transparent">
                                    <div class="float-right">
                                        <small><a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/pages"><?php echo __("See All");?>
</a></small>
                                    </div>
                                    <?php echo __("Suggested Pages");?>

                                </div>
                                <div class="card-body with-list">
                                    <ul>
                                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['new_pages']->value, '_page');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['_page']->value) {
?>
                                        <?php $_smarty_tpl->_subTemplateRender('file:__feeds_page.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('_tpl'=>"list"), 0, true);
?>
                                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                    </ul>
                                </div>
                            </div>
                        <?php }?>
                        <!-- suggested pages -->

                        <!-- Suggested panels -->
                        <?php if (count($_smarty_tpl->tpl_vars['new_groups']->value) > 0) {?>
                            <div class="card">
                                <div class="card-header bg-transparent">
                                    <div class="float-right">
                                        <small><a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/groups"><?php echo __("See All");?>
</a></small>
                                    </div>
                                    <?php echo __("Suggested panels");?>

                                </div>
                                <div class="card-body with-list">
                                    <ul>
                                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['new_groups']->value, '_group');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['_group']->value) {
?>
                                        <?php $_smarty_tpl->_subTemplateRender('file:__feeds_group.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('_tpl'=>"list"), 0, true);
?>
                                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                    </ul>
                                </div>
                            </div>
                        <?php }?>
                        <!-- Suggested panels -->

                        <!-- suggested events -->
                        <?php if (count($_smarty_tpl->tpl_vars['new_events']->value) > 0) {?>
                            <div class="card">
                                <div class="card-header bg-transparent">
                                    <div class="float-right">
                                        <small><a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/events"><?php echo __("See All");?>
</a></small>
                                    </div>
                                    <?php echo __("Suggested Events");?>

                                </div>
                                <div class="card-body with-list">
                                    <ul>
                                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['new_events']->value, '_event');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['_event']->value) {
?>
                                        <?php $_smarty_tpl->_subTemplateRender('file:__feeds_event.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('_tpl'=>"list",'_small'=>true), 0, true);
?>
                                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                    </ul>
                                </div>
                            </div>
                        <?php }?>
                        <!-- suggested events -->
                         <!-- invitation widget -->
                         <?php if ($_smarty_tpl->tpl_vars['system']->value['invitation_widget_enabled']) {?>
                            <div class="card">
                                <div class="card-header bg-transparent">
                                     <img class="iconsfriend" src="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/content/themes/<?php echo $_smarty_tpl->tpl_vars['system']->value['theme'];?>
/images/icons/friend.svg" class="mr5"> <?php echo __("Invite Your Friends");?>

                                </div>
                                <div class="card-body with-form">
                                    <form class="js_ajax-forms" data-url="users/invitation.php">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <input type="text" class="form-control" name="email" placeholder='<?php echo __("Email");?>
'>
                                                <div class="input-group-append">
                                                    <button type="submit" name="submit" class="btn btn-primary plr20"><i class="fas fa-paper-plane"></i></button>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- success -->
                                        <div class="alert alert-success mb0 x-hidden"></div>
                                        <!-- success -->

                                        <!-- error -->
                                        <div class="alert alert-danger mb0 x-hidden"></div>
                                        <!-- error -->
                                    </form>
                                </div>
                            </div>
                        <?php }?>
                        <!-- invitation widget -->

                        <!-- mini footer -->
                        <?php if (count($_smarty_tpl->tpl_vars['user']->value->_data['new_people']) > 0 || count($_smarty_tpl->tpl_vars['new_pages']->value) > 0 || count($_smarty_tpl->tpl_vars['new_groups']->value) > 0 || count($_smarty_tpl->tpl_vars['new_events']->value) > 0) {?>
                            <div class="mtb20 plr10 d-none d-sm-block">
                                <div class="col-12 mb5">
                                  <div class="row footer <?php if ($_smarty_tpl->tpl_vars['page']->value == 'index' && !$_smarty_tpl->tpl_vars['user']->value->_logged_in) {?>border-top-0<?php }?>">
	     <div class="col-sm-12 text-center" style="" ><?php echo __("Sponsored by :<br>His Royal Highness Prince Meteb Bin Abdulaziz Al Saud and his sons");?>
</div>




		<div class="col-sm-12 text-center">
        <br/>
        <hr/><hr style="margin-top: -1rem;margin-bottom: 1rem;border-top: 2px solid rgb(41, 182, 172);" />
	     	<!-- { if count($static_pages) > 0 } 
				 { foreach $static_pages as $static_page }
					<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/static/<?php echo $_smarty_tpl->tpl_vars['static_page']->value['page_url'];?>
">
						{ __($static_page['page_title'])}
					</a><?php if (!$_smarty_tpl->tpl_vars['static_page']->last) {?> · <?php }?>
				{ /foreach }
			-->
			<?php if ($_smarty_tpl->tpl_vars['system']->value['directory_enabled']) {?>
				 
				<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/explorer"  >
					<?php echo __("Explorer");?>

				</a>
				|
			<?php }?>
		
		
			<?php if ($_smarty_tpl->tpl_vars['system']->value['market_enabled']) {?>
                 |
                <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/market"  >
                    <?php echo __("Market");?>

                </a>
            <?php }?>
            <?php if ($_smarty_tpl->tpl_vars['system']->value['forums_enabled']) {?>
                 |
                <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/forums"  >
                    <?php echo __("Forums");?>

                </a>
            <?php }?>

			<?php if ($_smarty_tpl->tpl_vars['system']->value['language']['title'] == 'English') {?>

			   

			    <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/static/about"  >
					<?php echo __("About");?>

				</a>

				|
				<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/static/terms"  >
					<?php echo __("Terms");?>

				</a>
				|
				<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/static/privacy"  >
					<?php echo __("Privacy");?>

				</a>
				|
				<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/static/IntellectualProperty"  >
					<?php echo __("IntellectualProperty");?>

				</a>

				<?php if ($_smarty_tpl->tpl_vars['system']->value['contact_enabled']) {?>
				 | 
				<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/contacts"  >
					<?php echo __("Contacts");?>

				</a>
				|
			<?php }?>
				
				<a href="https://docs.google.com/forms/d/e/1FAIpQLSfw6Ct-qiKVXFsSpLD_v2mHnVgtHc37ig6-vn2I5fhvmwCoDg/viewform" target="_blank" >
					<?php echo __("Volunteers");?>

				</a>
				|
				<a href="https://docs.google.com/forms/d/e/1FAIpQLSfUpCxOqXw4AqRPFGQ6CtKaNLWNsVnrtAu3m0ccoXfylvVu6w/viewform" target="_blank" >
					<?php echo __("Careers");?>

				</a>
				


			<?php } elseif ($_smarty_tpl->tpl_vars['system']->value['language']['code'] == 'ar_sa') {?>
                 
			    <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/static/About_Ar"  > 
					<?php echo __("About_Ar");?>

				</a>
                 |
				<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/static/terms_Ar"  >
					<?php echo __("terms_Ar");?>

				</a>
				|
				<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/static/privacy_Ar"  >
					<?php echo __("privacy_Ar");?>

				</a>
				|
				<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/static/IntellectualPropertyAr"  >
					<?php echo __("IntellectualPropertyAr");?>

				</a>
				
				<?php if ($_smarty_tpl->tpl_vars['system']->value['contact_enabled']) {?>
				 | 
				<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/contacts"  >
					<?php echo __("Contacts");?>

				</a>
			<?php }?>
			|
				<a href="https://docs.google.com/forms/d/e/1FAIpQLSfw6Ct-qiKVXFsSpLD_v2mHnVgtHc37ig6-vn2I5fhvmwCoDg/viewform" target="_blank" >
					<?php echo __("Volunteers");?>

				</a>
				|
				<a href="https://docs.google.com/forms/d/e/1FAIpQLSfUpCxOqXw4AqRPFGQ6CtKaNLWNsVnrtAu3m0ccoXfylvVu6w/viewform" target="_blank" >
					<?php echo __("Careers");?>

				</a>
				
				
			<?php }?>


			
<br/><br/>
<hr/>
		 &copy; 2020 <?php echo __("Aaynet");?>
 · 
		</div>
		
		
	</div>
                                <div class="col-12 text-center">

                                 
			
                                </div>
                            </div>
                        <?php }?>
                        <!-- mini footer -->
                        
                    </div>
                    <!-- right panel -->
                </div>
            </div>
            <!-- content panel -->

        </div>
    </div>

<?php }?>
<!-- page content -->

                   





<?php $_smarty_tpl->_subTemplateRender('file:_footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
