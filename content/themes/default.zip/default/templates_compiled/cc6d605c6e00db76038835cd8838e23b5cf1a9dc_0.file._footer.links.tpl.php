<?php
/* Smarty version 3.1.33, created on 2019-11-12 14:20:56
  from 'C:\laragon\www\aaynet\content\themes\default\templates\_footer.links.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dcabfc81cb273_37630612',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cc6d605c6e00db76038835cd8838e23b5cf1a9dc' => 
    array (
      0 => 'C:\\laragon\\www\\aaynet\\content\\themes\\default\\templates\\_footer.links.tpl',
      1 => 1573568453,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dcabfc81cb273_37630612 (Smarty_Internal_Template $_smarty_tpl) {
?><!-- footer links -->
<div class="container">
	<div class="row footer <?php if ($_smarty_tpl->tpl_vars['page']->value == 'index' && !$_smarty_tpl->tpl_vars['user']->value->_logged_in) {?>border-top-0<?php }?>">
	<div class="col-sm-12 text-center" ><?php echo __("Sponsored by :<br>His Royal Highness Prince Meteb Bin Abdulaziz Al Saud and his sons");?>
</div>
	<div class="col-sm-5">
			&copy; 2020 <?php echo __("Aaynet");?>
 · 
			<span class="text-link" data-toggle="modal" data-url="#translator"><?php echo $_smarty_tpl->tpl_vars['system']->value['language']['title'];?>
 </span> 
	

			
			
		</div>

           <!-- <?php if ($_smarty_tpl->tpl_vars['system']->value['language']['code'] == "ar_sa") {?>
			  <?php echo __("English");?>

			<?php } elseif ($_smarty_tpl->tpl_vars['system']->value['language']['code'] == "en_us") {?>
			
			  <?php echo __("Arabic");?>


			<?php }?>
			-->





		<div class="col-sm-7 links">
	     	<!-- { if count($static_pages) > 0 } 
				 { foreach $static_pages as $static_page }
					<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/static/<?php echo $_smarty_tpl->tpl_vars['static_page']->value['page_url'];?>
">
						{ __($static_page['page_title'])}
					</a><?php if (!$_smarty_tpl->tpl_vars['static_page']->last) {?> · <?php }?>
				{ /foreach }
			-->
			<?php if ($_smarty_tpl->tpl_vars['system']->value['directory_enabled']) {?>
				 
				<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/explorer"  >
					<?php echo __("Explorer");?>

				</a>
				|
			<?php }?>
		
		
			<?php if ($_smarty_tpl->tpl_vars['system']->value['market_enabled']) {?>
                 |
                <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/market"  >
                    <?php echo __("Market");?>

                </a>
            <?php }?>
            <?php if ($_smarty_tpl->tpl_vars['system']->value['forums_enabled']) {?>
                 |
                <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/forums"  >
                    <?php echo __("Forums");?>

                </a>
            <?php }?>

			<?php if ($_smarty_tpl->tpl_vars['system']->value['language']['title'] == 'English') {?>

			   

			    <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/static/about"  >
					<?php echo __("About");?>

				</a>

				|
				<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/static/terms"  >
					<?php echo __("Terms");?>

				</a>
				|
				<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/static/privacy"  >
					<?php echo __("Privacy");?>

				</a>
				|
				<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/static/IntellectualProperty"  >
					<?php echo __("IntellectualProperty");?>

				</a>

				<?php if ($_smarty_tpl->tpl_vars['system']->value['contact_enabled']) {?>
				 | 
				<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/contacts"  >
					<?php echo __("Contacts");?>

				</a>
				|
			<?php }?>
				
				<a href="https://docs.google.com/forms/d/e/1FAIpQLSfw6Ct-qiKVXFsSpLD_v2mHnVgtHc37ig6-vn2I5fhvmwCoDg/viewform" target="_blank" >
					<?php echo __("Volunteers");?>

				</a>
				|
				<a href="https://docs.google.com/forms/d/e/1FAIpQLSfUpCxOqXw4AqRPFGQ6CtKaNLWNsVnrtAu3m0ccoXfylvVu6w/viewform" target="_blank" >
					<?php echo __("Careers");?>

				</a>
				


			<?php } elseif ($_smarty_tpl->tpl_vars['system']->value['language']['code'] == 'ar_sa') {?>
                 
			    <a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/static/About_Ar"  > 
					<?php echo __("About_Ar");?>

				</a>
                 |
				<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/static/terms_Ar"  >
					<?php echo __("terms_Ar");?>

				</a>
				|
				<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/static/privacy_Ar"  >
					<?php echo __("privacy_Ar");?>

				</a>
				|
				<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/static/IntellectualPropertyAr"  >
					<?php echo __("IntellectualPropertyAr");?>

				</a>
				
				<?php if ($_smarty_tpl->tpl_vars['system']->value['contact_enabled']) {?>
				 | 
				<a href="<?php echo $_smarty_tpl->tpl_vars['system']->value['system_url'];?>
/contacts"  >
					<?php echo __("Contacts");?>

				</a>
			<?php }?>
			|
				<a href="https://docs.google.com/forms/d/e/1FAIpQLSfw6Ct-qiKVXFsSpLD_v2mHnVgtHc37ig6-vn2I5fhvmwCoDg/viewform" target="_blank" >
					<?php echo __("Volunteers");?>

				</a>
				|
				<a href="https://docs.google.com/forms/d/e/1FAIpQLSfUpCxOqXw4AqRPFGQ6CtKaNLWNsVnrtAu3m0ccoXfylvVu6w/viewform" target="_blank" >
					<?php echo __("Careers");?>

				</a>
				
				
			<?php }?>


			

		
		</div>
		
		
	</div>
</div>
<!-- footer links --><?php }
}
